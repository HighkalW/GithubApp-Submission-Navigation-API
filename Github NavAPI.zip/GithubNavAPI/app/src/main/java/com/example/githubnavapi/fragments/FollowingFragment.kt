package com.example.githubnavapi.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubnavapi.config.GithubService
import com.example.githubnavapi.config.Items
import com.example.githubnavapi.adapter.ListGithubAdapter
import com.example.githubnavapi.activity.DetailGithubActivity
import com.example.githubnavapi.databinding.FragmentFollowingBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowingFragment : Fragment() {
    private var fbinding: FragmentFollowingBinding? = null
    private val binding get() = fbinding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        fbinding = FragmentFollowingBinding.inflate(inflater, container, false)
        binding.rvFollowing.layoutManager = LinearLayoutManager(context)

        binding.progressBar.visibility = View.VISIBLE

        GithubService.depRetrofit.getFollowing(DetailGithubActivity.DataUser.username.toString())
            .enqueue(object :
                Callback<List<Items>> {
                override fun onFailure(call: Call<List<Items>>, t: Throwable) {
                    Toast.makeText(context, t.message.toString(), Toast.LENGTH_SHORT).show()
                }

                override fun onResponse(call: Call<List<Items>>, response: Response<List<Items>>) {
                    val list = response.body()
                    binding.progressBar.visibility = View.GONE
                    val rvAdapter = list?.let { ListGithubAdapter(it) }
                    binding.rvFollowing.adapter = rvAdapter
                    binding.progressBar.visibility = View.GONE
                    rvAdapter?.setOnItemClickCallback(object :
                        ListGithubAdapter.OnItemClickCallback {
                        override fun onItemClicked(data: Items) {
                            val moveDetailGithub =
                                Intent(requireContext(), DetailGithubActivity::class.java)
                            moveDetailGithub.putExtra("username", data.login)
                            startActivity(moveDetailGithub)
                        }
                    })
                }
            })
        return binding.root

    }
}