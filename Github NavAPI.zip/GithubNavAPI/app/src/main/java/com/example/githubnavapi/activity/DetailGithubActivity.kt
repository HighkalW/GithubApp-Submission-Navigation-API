package com.example.githubnavapi.activity


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.viewpager2.widget.ViewPager2
import coil.load
import com.example.githubnavapi.config.DetailUserData
import com.example.githubnavapi.config.GithubService
import com.example.githubnavapi.R
import com.example.githubnavapi.adapter.SectionsPagerAdapter
import com.example.githubnavapi.databinding.ActivityDetailGithubBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class DetailGithubActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var binding: ActivityDetailGithubBinding


    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailGithubBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backIcon.setOnClickListener(this)

        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f

        binding.progressBar.visibility = View.VISIBLE

        val username = intent.extras?.get("username")
        DataUser.username = username.toString()
        val retrofit = GithubService.depRetrofit.getDetailuser(username as String)

        retrofit.enqueue(object : Callback<DetailUserData> {
            override fun onFailure(call: Call<DetailUserData>, t: Throwable) {
                Toast.makeText(this@DetailGithubActivity, t.message.toString(), Toast.LENGTH_SHORT).show()
                Log.d("error", t.message.toString())
            }

            override fun onResponse(
                call: Call<DetailUserData>,
                response: Response<DetailUserData>
            ) {
                val dataResponse: DetailUserData = response.body()!!
                binding.tvDetailRepository.text = dataResponse.publicRepos.toString()
                binding.tvDetailId.text = dataResponse.id.toString()
                binding.tvDetailFollower.text = dataResponse.followers.toString()
                binding.tvDetailFollowing.text = dataResponse.following.toString()
                binding.tvDetailLocation.text = dataResponse.location
                binding.tvDetailUsername.text = dataResponse.login
                binding.tvDetailName.text = dataResponse.name
                binding.tvDetailCompany.text = dataResponse.company
                binding.ivDetailImgGithub.load(dataResponse.avatarUrl)
            }

        })
        binding.progressBar.visibility = View.GONE

    }


    object DataUser {
        var username: String? = null
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.back_icon -> {
                finish()
            }
        }
    }
}




