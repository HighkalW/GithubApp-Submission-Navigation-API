package com.example.githubnavapi

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.githubnavapi.config.GithubService
import com.example.githubnavapi.config.Items
import com.example.githubnavapi.config.SearchData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel : ViewModel() {

    private val _responsegithub = MutableLiveData<SearchData>()
    val responsegithub: LiveData<SearchData> = _responsegithub
    private val _listdata = MutableLiveData<List<Items>>()
    val listData: LiveData<List<Items>> = _listdata
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    companion object{
        private const val TAG = "MainViewModel"
    }
     fun findData(searchData: String) {
        _isLoading.value = true
        val client = GithubService.depRetrofit.getSearch(searchData)
        client.enqueue(object : Callback<SearchData> {
            override fun onResponse(
                call: Call<SearchData>,
                response: Response<SearchData>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _listdata.value = response.body()?.items
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<SearchData>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
    }
}
