package com.example.githubnavapi.config

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface GithubInterface {
    @GET("/search/users")
    fun getSearch(@Query("q") q: String): Call<SearchData>

    @GET("/users/{username}")
    fun getDetailuser(@Path("username") username: String): Call<DetailUserData>

    @GET("/users/{username}/followers")
    fun getFollower(@Path("username") username: String): Call<List<Items>>

    @GET("/users/{username}/following")
    fun getFollowing(@Path("username") username: String): Call<List<Items>>
}