package com.example.githubnavapi.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.SearchView
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubnavapi.*
import com.example.githubnavapi.adapter.ListGithubAdapter
import com.example.githubnavapi.config.GithubService
import com.example.githubnavapi.config.Items
import com.example.githubnavapi.config.SearchData
import com.example.githubnavapi.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(MainViewModel::class.java)
        val layoutManager = LinearLayoutManager(this)
        binding.rvGithub.layoutManager = layoutManager
        mainViewModel.listData.observe(this) { items ->
            setListData(items)
        }

        mainViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        binding.iconSetting.setOnClickListener(this)

        binding.rvGithub.layoutManager = LinearLayoutManager(this)

        binding.searchBar.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                mainViewModel.findData(query)
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE

    }

    private fun setListData(items: List<Items>?) {
        val rvAdapter = ListGithubAdapter(items as List<Items>)
        binding.rvGithub.adapter = rvAdapter
        rvAdapter.setOnItemClickCallback(object :
            ListGithubAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Items) {
                val moveDetailGithub =
                    Intent(this@MainActivity, DetailGithubActivity::class.java)
                moveDetailGithub.putExtra("username", data.login)
                startActivity(moveDetailGithub)
            }
        })
        binding.progressBar.visibility = View.GONE

    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.icon_setting -> {
                val mIntent = Intent(Settings.ACTION_LOCALE_SETTINGS)
                startActivity(mIntent)
            }
        }
    }
}


