package com.example.githubnavapi.adapter


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.githubnavapi.config.Items
import com.example.githubnavapi.databinding.ItemRowGithubBinding

class ListGithubAdapter(private val listGithub: List<Items>) :
    RecyclerView.Adapter<ListGithubAdapter.ListViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: Items)
    }

    class ListViewHolder(val binding: ItemRowGithubBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ListViewHolder {
        val binding =
            ItemRowGithubBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        return ListViewHolder(binding)
    }

    override fun getItemCount(): Int = listGithub.size
    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        holder.binding.apply {
            civPhotoGithub.load(listGithub[position].avatarUrl)
            tvUsernameGithub.text = listGithub[position].login
            root.setOnClickListener { onItemClickCallback.onItemClicked(listGithub[holder.adapterPosition]) }
        }
    }
}